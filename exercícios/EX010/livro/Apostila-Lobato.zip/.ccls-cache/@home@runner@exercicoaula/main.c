#include <stdio.h>

int main(void) {
  int: n1,n2;
  printf("Escreva n1");
    scanf("n1");
    printf("Escreva n2");
  scanf("n2");
  printf("A soma %d, a diferença %d, o produto %d, e a divisão %d, de n1 e n2 é", n1 + n2, n1 - n2, n1 * n2, n1 / n2);
  return 0;
}