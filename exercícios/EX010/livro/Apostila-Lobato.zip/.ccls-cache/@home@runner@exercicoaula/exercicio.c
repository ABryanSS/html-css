#include <stdio.h>
#include <stdlib.h>
int main (void){
  int a;
printf("Digite um numero inteiro:");
  scanf("%d",&a);
    if(a)









return 0;  
}


  
  
