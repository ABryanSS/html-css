/*Um hectare (10.000 m2) de terra produz 150 toneladas de cana de açúcar. Faça
um algoritmo que exiba quantas toneladas de cana serão produzidas em um sítio
cuja quantidade de hectares será informada pelo usuário.*/
/*#include <stdio.h>
int main(void)
{
int hectare,cana_de_acucar,total;
 printf("Informe a quantidade de hectares:\n");
  scanf("%d", &hectare);
  cana_de_acucar = 150;
  total = hectare * cana_de_acucar;
  printf("O total de toneladas de cana de açucar produzido é: %d toneladas.",total);
  return 0;
}*/