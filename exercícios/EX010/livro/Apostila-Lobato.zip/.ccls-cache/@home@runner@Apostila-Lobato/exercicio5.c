/*Fazer um algoritmo para calcular a área de um quadrado.*/
/*#include <stdio.h>
int main(void){
  int n1,n2;
  printf("Escreva o valor de um lado do quadrado:\n");
  scanf("%d",&n1);
  n2 = n1 * n1;
  printf("O valor da área do quadrado é:%d ao quadrado",n2);
  return 0;
}*/