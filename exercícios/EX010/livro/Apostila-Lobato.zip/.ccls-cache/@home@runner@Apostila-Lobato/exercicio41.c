/*Construa um algoritmo que receba o ano de nascimento do usuário e verifique se
ele tem mais de 21 anos.*/
/*#include <stdio.h>
#include <time.h>

int main() {
    int ano_nascimento, idade;

    printf("Digite o ano de nascimento: ");
    scanf("%d", &ano_nascimento);

    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    int ano_atual = tm.tm_year + 1900;

    idade = ano_atual - ano_nascimento;

    if (idade > 21) {
        printf("Voce tem mais de 21 anos.\n");
    } else if (idade == 21) {
        printf("Voce tem exatamente 21 anos.\n");
    } else {
        printf("Voce tem menos de 21 anos.\n");
    }

    return 0;
}*/