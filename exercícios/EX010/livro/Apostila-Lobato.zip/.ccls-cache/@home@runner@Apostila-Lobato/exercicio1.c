/*#include <stdio.h>
int main (void){
int n1,n2,n3;
  printf("Escreva dois numeros\n");
    scanf("%d %d",&n1,&n2);
  n3 = n1 + n2;
  printf(" A soma entre %d e %d é:%d",n1,n2,n3);
   return 0;
    }*/




  
  
