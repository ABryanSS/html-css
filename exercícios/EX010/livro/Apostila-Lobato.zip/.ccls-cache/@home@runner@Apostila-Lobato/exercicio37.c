/*Dado um número de três algarismos, construir outro número de quatro algarismos
de acordo com a seguinte regra:
a) os três primeiros algarismos, contados da esquerda para a direita, são iguais aos
do número dado;
b) O quarto algarismo é um dígito de controle calculado da seguinte forma:
[ (N1 + N2) * 3 + N3 * 5 ]
O dígito de controle é igual ao resto da divisão dessa soma por 7.*/
/*#include <stdio.h>

int main() {
    int num, n1, n2, n3, dControl, newNum;
    
    printf("Digite um número de três algarismos: ");
    scanf("%d", &num);
    
    n1 = num / 100;
    n2 = (num / 10) % 10;
    n3 = num % 10;
    
    dControl = ((n1 + n2) * 3 + n3 * 5) % 7;
    
    newNum = num * 10 + dControl;
    
    printf("Novo número: %d", newNum);
    
    return 0;
}*/