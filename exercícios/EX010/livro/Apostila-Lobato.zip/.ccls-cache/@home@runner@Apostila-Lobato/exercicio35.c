/*Escreva um algoritmo que receba uma quantia em reais(acima de R$50,00) e
determine o número de cédulas de 50, 10, e 1. Utilizar sempre cédulas de maior valor
possível e não considerar centavos.*/
/*#include <stdio.h>

int main() {
    int valor, ced50, ced10, ced1;

    printf("Digite o valor em reais (acima de R$50,00): ");
    scanf("%d", &valor);

    ced50 = valor / 50; //calcula o número de cédulas de 50
    valor %= 50; //calcula o resto após a divisão por 50

    ced10 = valor / 10; //calcula o número de cédulas de 10
    valor %= 10; //calcula o resto após a divisão por 10

    ced1 = valor; //o resto é o número de cédulas de 1

    printf("Número de cédulas de 50: %d\n", ced50);
    printf("Número de cédulas de 10: %d\n", ced10);
    printf("Número de cédulas de 1: %d\n", ced1);

    return 0;
}*/