
/*Faça um algoritmo que leia dois valores inteiros representando, respectivamente
um valor de hora e um de minutos. Calcule quantos minutos se passaram desde o
início do dia.*/
/*#include <stdio.h>
int main(){
  int horas,minutos,tmin;
printf("Informe a hora:\n");
   scanf("%d",&horas);
  printf("Informe os minutos:\n");
   scanf("%d",&minutos);
 tmin = (horas * 60 ) + minutos;
printf("Se passaram %d minutos desde o inicio do dia",tmin);
return 0;
}*/