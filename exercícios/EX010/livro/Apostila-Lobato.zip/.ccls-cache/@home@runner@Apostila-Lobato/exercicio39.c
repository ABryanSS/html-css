/*Elabore um algoritmo que leia o nome e o número de horas trabalhadas de um
operário e calcule o seu salário sabendo-se que:
a) Hora trabalhada W R$5,20;
b) Quando o número de horas exceder a 44, a hora excedente vale W R$ 8,40.*/
/*#include <stdio.h>

int main() {
    char nome[50];
    int horas_trabalhadas;
    float salario;

    printf("Digite o nome do operario: ");
    scanf("%s", nome);

    printf("Digite o numero de horas trabalhadas: ");
    scanf("%d", &horas_trabalhadas);

    if (horas_trabalhadas > 44) {
        salario = 44 * 5.2 + (horas_trabalhadas - 44) * 8.4;
    } else {
        salario = horas_trabalhadas * 5.2;
    }

    printf("Salario de %s: R$%.2f\n", nome, salario);

    return 0;
}*/