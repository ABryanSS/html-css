/*Faça um algoritmo que leia dois números inteiros e imprima uma mensagem se
são iguais ou diferentes.*/
/*#include <stdio.h>

int main() {
    int num1, num2;
    
    printf("Digite o primeiro numero: ");
    scanf("%d", &num1);
    
    printf("Digite o segundo numero: ");
    scanf("%d", &num2);
    
    if(num1 == num2) {
        printf("Os numeros sao iguais.\n");
    } else {
        printf("Os numeros sao diferentes.\n");
    }
    
    return 0;
}*/