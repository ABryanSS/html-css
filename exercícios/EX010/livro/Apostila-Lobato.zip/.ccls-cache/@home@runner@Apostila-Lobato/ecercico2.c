/*Fazer um algoritmo para calcular a soma entre dois números e multiplicar o
resultado pelo primeiro.*/
/*#include <stdio.h>
int main (void){
int n1,n2,n3,n4;
  printf("Escreva dois numeros\n");
    scanf("%d %d",&n1,&n2);
  n3 = n1 + n2;
  n4 = n1 * n3;
  printf("A multiplicação de %d por %d é: %d",n1,n3,n4);
   return 0;
    }*/