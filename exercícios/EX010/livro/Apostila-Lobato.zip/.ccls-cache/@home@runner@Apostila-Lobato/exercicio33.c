/*Numa loja de eletrodomésticos, o comerciário encarregado da seção de televisores
recebe, mensalmente, um salário fixo mais comissão. Essa comissão é calculada em
relação ao tipo e ao número de televisores vendidos por mês, obedecendo a tabela
abaixo:
TIPO Número de Televisores Vendidos Comissão
Color 14” Menor que 10 R$20,00 por televisor vendido
Maior ou igual a 10 R$25,00 por televisor vendido
Color 20” Menor que 5 R$25,00 por televisor vendido
Maior ou igual a 5 R$30,00 por televisor vendido
Sabe-se ainda que ele tem um desconto de 8% sobre o salário fixo para o INSS.
Faça um algoritmo para ler o nome, o salário fixo do funcionário e o número de
televisores de cada tipo e calcule o salário do funcionário.
A resposta deve ser apresentada conforme o modelo abaixo:
Nome: Fulano de Tal
Nr de TVs Color 14” vendidas: X
Nr de TVs Color 20” vendidas: Y
Salário Bruto: R$ .....................
Salário Líquido: R$ ..................*/
/*#include <stdio.h>

int main() {
    char nome[100];
    int qtd_tv_color14, qtd_tv_color20;
    float salario_fixo, comissao, salario_bruto, salario_liquido;
    
    // leitura dos dados
    printf("Digite o nome do funcionário: ");
    fgets(nome, 100, stdin);
    printf("Digite o salário fixo do funcionário: ");
    scanf("%f", &salario_fixo);
    printf("Digite a quantidade de TVs Color 14\" vendidas: ");
    scanf("%d", &qtd_tv_color14);
    printf("Digite a quantidade de TVs Color 20\" vendidas: ");
    scanf("%d", &qtd_tv_color20);
    
    // cálculo da comissão
    if (qtd_tv_color14 < 10) {
        comissao = qtd_tv_color14 * 20.0;
    } else {
        comissao = qtd_tv_color14 * 25.0;
    }
    if (qtd_tv_color20 < 5) {
        comissao += qtd_tv_color20 * 25.0;
    } else {
        comissao += qtd_tv_color20 * 30.0;
    }
    
    // cálculo do salário bruto e líquido
    salario_bruto = salario_fixo + comissao;
    salario_liquido = salario_bruto * 0.92; // desconto de 8% para o INSS
    
    // impressão dos resultados
    printf("\nNome: %s", nome);
    printf("Nr de TVs Color 14\" vendidas: %d\n", qtd_tv_color14);
    printf("Nr de TVs Color 20\" vendidas: %d\n", qtd_tv_color20);
    printf("Salário Bruto: R$ %.2f\n", salario_bruto);
    printf("Salário Líquido: R$ %.2f\n", salario_liquido);
    
    return 0;
}*/