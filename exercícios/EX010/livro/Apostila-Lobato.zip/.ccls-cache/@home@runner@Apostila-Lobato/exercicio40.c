/*Construa um algoritmo para calcular o peso ideal de uma pessoa. Dados de
entrada: altura e sexo.
Fórmula para o cálculo:
PESO IDEAL HOMEM: ( 72,7 * ALTURA ) – 58
PESO IDEAL MULHER: ( 62,1 * ALTURA ) – 44,7*/
/*#include <stdio.h>

int main() {
    float altura, peso_ideal;
    char sexo;

    printf("Digite a altura (em metros): ");
    scanf("%f", &altura);

    printf("Digite o sexo (M para masculino ou F para feminino): ");
    scanf(" %c", &sexo);

    if (sexo == 'M') {
        peso_ideal = 72.7 * altura - 58;
    } else if (sexo == 'F') {
        peso_ideal = 62.1 * altura - 44.7;
    } else {
        printf("Sexo invalido!\n");
        return 1;
    }

    printf("O peso ideal para uma pessoa do sexo %c com altura %.2f m eh %.2f kg.\n", sexo, altura, peso_ideal);

    return 0;
}*/