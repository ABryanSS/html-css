/*Faça um algoritmo que leia dois números inteiros e imprima o resto da divisão de
um pelo outro.*/
/*#include <stdio.h>

int main() {
    int numero1, numero2, restoDivisao;

    printf("Digite o primeiro numero inteiro: ");
    scanf("%d", &numero1);

    printf("Digite o segundo numero inteiro: ");
    scanf("%d", &numero2);

    // Cálculo do resto da divisão
    restoDivisao = numero1 % numero2;

    printf("O resto da divisao de %d por %d e: %d", numero1, numero2, restoDivisao);

    return 0;
}*/