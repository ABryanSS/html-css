/*Construa um algoritmo que receba o código de um produto e o classifique de
acordo com a tabela abaixo:
CÓDIGO CLASSIFICAÇÃO
1 Alimento não perecível
2 Alimento perecível
3 Vestuário
4 Higiene pessoal
5 Limpeza*/
/*#include <stdio.h>

int main() {
    int codigo;

    printf("Digite o codigo do produto: ");
    scanf("%d", &codigo);

    switch (codigo) {
        case 1:
            printf("Classificacao: ALIMENTO NAO PERECIVEL\n");
            break;
        case 2:
            printf("Classificacao: ALIMENTO PERECIVEL\n");
            break;
        case 3:
            printf("Classificacao: VESTUARIO\n");
            break;
        case 4:
            printf("Classificacao: HIGIENE PESSOAL\n");
            break;
        case 5:
            printf("Classificacao: LIMPEZA\n");
            break;
        default:
            printf("Classificacao: CODIGO INVALIDO\n");
            break;
    }

    return 0;
}*/