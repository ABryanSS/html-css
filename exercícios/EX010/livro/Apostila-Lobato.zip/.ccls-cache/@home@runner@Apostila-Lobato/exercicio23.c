/*Fazer um algoritmo para calcular o volume de uma esfera de raio R.*/
/*#include <stdio.h>
#include <math.h>

int main() {
    float raio, volume;
    const float PI = 3.14159265359;

    // Lê o raio da esfera do usuário
    printf("Digite o raio da esfera: ");
    scanf("%f", &raio);

    // Calcula o volume da esfera
    volume = (4.0/3.0) * PI * pow(raio, 3);

    // Imprime o resultado
    printf("O volume da esfera de raio %.2f é %.2f\n", raio, volume);

    return 0;
}*/