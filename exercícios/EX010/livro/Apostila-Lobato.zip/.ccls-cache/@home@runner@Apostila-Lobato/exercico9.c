/*Calcular o valor total de um determinado pagamento a ser realizado, incluindo a
taxa de juros.*/
/*#include <stdio.h>
int main(void){
float pago,juros,total,pagojuros;
  printf("Digite o valor do pagamento:\n");
    scanf("%f",&pago);
  juros = 0.10;
  pagojuros = pago * juros;
  total = pago + pagojuros;
  printf("O valor total a ser pago é:%.1f",total);
                                     
  return 0;
}*/





