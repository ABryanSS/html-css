/*fazer um algoritmo para calcular a média final (média aritmética) de um aluno,
considerando a realização de quatro avaliações.*/
/*#include <stdio.h>
int main(void){
  float n1,n2,n3,n4,media;
  printf(" Escreva a nota das 4 avaliações:\n");
    scanf("%f %f %f %f",&n1,&n2,&n3,&n4);
      media = (n1 + n2 + n3 + n4)/4;
  printf(" A media das quatro avaliações é:%.2f",media);
  return 0;
}*/