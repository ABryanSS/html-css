/*Faça um algoritmo que leia um horário no sistema de 24 horas e imprima este
horário no sistema 12 horas.
Ex: 22:32 W 10:32 pm 09:10 h W 09:10 am*/
/*#include <stdio.h>

int main() {
    int hora, minuto;
    char periodo[3];

    printf("Digite o horario no formato 24h (ex: 22:32): ");
    scanf("%d:%d", &hora, &minuto);

    // Determinar o periodo do dia (AM ou PM)
    if (hora < 12) {
        strcpy(periodo, "AM");
    } else {
        strcpy(periodo, "PM");
    }

    // Converter para o formato 12h
    if (hora == 0) {
        hora = 12;
    } else if (hora > 12) {
        hora -= 12;
    }

    printf("Horario no formato 12h: %02d:%02d %s\n", hora, minuto, periodo);

    return 0;
}*/