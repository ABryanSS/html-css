/*16.Dado um número inteiro, obter o último algarismo desse número.*/
/*#include <stdio.h>

int main() {
    int numero, ultimoAlgarismo;

    printf("Digite um numero inteiro: ");
    scanf("%d", &numero);

    // Obtenção do último algarismo
    ultimoAlgarismo = numero % 10;

    printf("O ultimo algarismo do numero e: %d", ultimoAlgarismo);

    return 0;
}*/