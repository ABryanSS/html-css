/*Fazer um algoritmo que leia um número inteiro e imprima o seu valor absoluto
(sem sinal).*/
/*#include <stdio.h>

int main() {
    int num;

    printf("Digite um numero inteiro: ");
    scanf("%d", &num);

    if (num < 0) {
        num = -num;
    }

    printf("Valor absoluto: %d\n", num);

    return 0;
}*/