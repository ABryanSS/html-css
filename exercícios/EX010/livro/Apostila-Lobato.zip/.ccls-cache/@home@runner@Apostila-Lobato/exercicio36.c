/*Faça um algoritmo que leia três números inteiros e exiba uma(e apenas uma) das
seguintes mensagens:
- Todos os números são iguais
- Todos os números são diferentes
- Apenas dois números são iguais*/
/*#include <stdio.h>

int main() {
    int num1, num2, num3;
    
    printf("Digite o primeiro número: ");
    scanf("%d", &num1);
    
    printf("Digite o segundo número: ");
    scanf("%d", &num2);
    
    printf("Digite o terceiro número: ");
    scanf("%d", &num3);
    
    if (num1 == num2 && num1 == num3) {
        printf("Todos os números são iguais.\n");
    } else if (num1 != num2 && num1 != num3 && num2 != num3) {
        printf("Todos os números são diferentes.\n");
    } else {
        printf("Apenas dois números são iguais.\n");
    }
    
    return 0;
}*/