/*Modifique o algoritmo anterior sabendo-se que:
- uma tonelada de cana vale R$1.000,00, exiba o total arrecadado com a venda;
- O custo de produção é de 60% do valor de venda. Mostre o lucro com a produção.*/
/*#include <stdio.h>
int main(void)
{
int hectare,cana_de_acucar,total1,valor_cana,despesa,lucro;
 printf("Informe a quantidade de hectares:\n");
  scanf("%d", &hectare);
  cana_de_acucar = 150;
  total1 = hectare * cana_de_acucar;
valor_cana = total1 * 1000;
despesa = valor_cana * 0.6;
lucro = valor_cana - despesa;
  printf("O total de toneladas de cana de açucar produzido é: %d toneladas, o total de dinheiro arrecadado é:%d reais, e o lucro é:%d reais.",total1,valor_cana,lucro);
  return 0;
}*/