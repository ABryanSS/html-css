/* Fazer um algoritmo para receber um valor em dólar e converter esse valor em
real.*/
#include <stdio.h>
int main(voide){
  float n1,n2,n3;
  n2 = 0.197;
  printf("Escreva o valor em reais:\n");
    scanf("%f",&n1);
    n3 = n1 * n2;
  printf("O valor em dolar do valor é:%f",n3);
  
  return 0;
}