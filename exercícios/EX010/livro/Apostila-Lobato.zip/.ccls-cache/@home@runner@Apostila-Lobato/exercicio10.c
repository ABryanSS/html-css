/*Faça um algoritmo que leia o horário de entrada (hora e minuto) e o horário de
saída (hora e minuto) de um empregado e imprima quanto tempo, no formato
HORA:MINUTO o empregado ficou na empresa.*/
/*#include <stdio.h>
int main(void){
int hora1,min1,hora2,min2,hora3,min3;
  printf("Escreva as horas e minutos de entrada em modelo 24h:\n");
    scanf("%d %d",&hora1,&min1);
  printf("Escreva as horas e minutos de saida em modelo 24h:\n");
    scanf("%d %d",&hora2,&min2);
  hora3 = hora2 - hora1;
  min3 = min2 - min1;
  printf("O funcionário ficou na empresa %d horas e %d minutos\n",hora3,min3);
  return 0;
}*/



