/*Fazer um algoritmo que leia um número inteiro e exiba o seu antecessor e o seu
sucessor.*/
/*#include <stdio.h>
int main(void){
int n1,n2,n3;
  printf("Escreva um número inteiro:\n");
  scanf("%d",&n1);
  n2 = n1 - 1;
  n3 = n1 + 1;
  printf("O número é:%d, o seu antecessor é:%d, o seu sucessor é:%d",n1,n2,n3);
  return 0;
}*/
  