/*Fazer um algoritmo para calcular a soma, a diferença, o produto e a divisão de
dois números inteiros.*/
/*#include <stdio.h>
int main(void){
int n1,n2,soma,diferenca,produto,divisao;
  printf("Esvreva dois números inteiros:\n");
  scanf("%d %d",&n1,&n2);
  soma = n1 + n2;
  diferenca = n1 - n2;
  produto = n1 * n2;
  divisao =  n1 / n2;
  printf("A soma é: %d, a diferença é: %d, o produto é: %d, a divisão é: %d",soma,diferenca,produto,divisao);
  return 0;
}*/