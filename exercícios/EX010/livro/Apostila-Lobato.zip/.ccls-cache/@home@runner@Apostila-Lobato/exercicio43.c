/*Faça um algoritmo que leia a idade de uma pessoa e informa sua classe eleitoral,
conforme a regra abaixo:
- Não Eleitor W menor de 16 anos;
- Eleitor obrigatório W de 18 a 65 anos;
- Eleitor facultativo W entre 16 e 18 anos e acima de 65 anos.*/
/*#include <stdio.h>

int main() {
    int idade;

    printf("Digite a idade: ");
    scanf("%d", &idade);

    if (idade < 16) {
        printf("Classe Eleitoral: NAO ELEITOR\n");
    } else if (idade >= 18 && idade <= 65) {
        printf("Classe Eleitoral: ELEITOR OBRIGATORIO\n");
    } else {
        printf("Classe Eleitoral: ELEITOR FACULTATIVO\n");
    }

    return 0;
}*/