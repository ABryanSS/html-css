/* Fazer um algoritmo para ler o ano de nascimento de uma pessoa e imprima que
idade terá no ano corrente.*/
/*#include <stdio.h>
#include <time.h>

int main() {
    int anoNascimento, anoCorrente, idade;

    // Obtém o ano corrente
    time_t agora = time(NULL);
    struct tm *data = localtime(&agora);
    anoCorrente = data->tm_year + 1900;

    // Lê o ano de nascimento da pessoa
    printf("Digite o ano de nascimento: ");
    scanf("%d", &anoNascimento);

    // Calcula a idade
    idade = anoCorrente - anoNascimento;

    // Imprime a idade
    printf("A pessoa tera %d anos no ano corrente.\n", idade);

    return 0;
}*/