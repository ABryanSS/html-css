/*Um certo tipo de aço é classificado de acordo com o resultado de 3 testes, que
devem verificar se o mesmo satisfaz às seguintes especificações:
- Teste 1 – Conteúdo de carbono abaixo de 7%;
- Teste 2 – Dureza maior que 50;
- Teste 3 – Resistência à tração maior que 10.000.
Ao aço é atribuído o grau 10 se passar nos 3 testes; 9 se passar nos testes 1 e 2; 8 se
passar no teste 1 e grau 7 se não passar no teste 1(não é necessário realizar os
outros testes.
Supondo que sejam lidos do teclado: número de amostra, conteúdo de carbono(em
%), a dureza e a resistência à tração, fazer um algoritmo que dê a classificação da
amostra de aço que foi testada, escrevendo o número da amostra e o grau obtido.*/
/*#include <stdio.h>

int main() {
    int num_amostra, grau;
    float carbono;
    int dureza, resistencia;

    printf("Digite o numero da amostra: ");
    scanf("%d", &num_amostra);

    printf("Digite o conteudo de carbono (em porcentagem): ");
    scanf("%f", &carbono);

    printf("Digite a dureza: ");
    scanf("%d", &dureza);

    printf("Digite a resistencia a tracao: ");
    scanf("%d", &resistencia);

    if (carbono < 7.0 && dureza > 50 && resistencia > 10000) {
        grau = 10;
    } else if (carbono < 7.0 && dureza > 50) {
        grau = 9;
    } else if (carbono < 7.0) {
        grau = 8;
    } else {
        grau = 7;
    }

    printf("Amostra %d - Grau %d\n", num_amostra, grau);

    return 0;
}*/