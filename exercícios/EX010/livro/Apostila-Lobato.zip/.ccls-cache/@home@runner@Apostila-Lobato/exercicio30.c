/*Faça um algoritmo que leia dois números inteiro e informe qual é o maior e o
menor ou se são iguais.*/
/*#include <stdio.h>

int main() {
    int num1, num2;
    
    printf("Digite o primeiro numero inteiro: ");
    scanf("%d", &num1);
    
    printf("Digite o segundo numero inteiro: ");
    scanf("%d", &num2);
    
    if(num1 == num2) {
        printf("Os numeros sao iguais.\n");
    } else if(num1 > num2) {
        printf("O primeiro numero digitado é maior.\n");
        printf("O segundo numero digitado é menor.\n");
    } else {
        printf("O segundo numero digitado é maior.\n");
        printf("O primeiro numero digitado é menor.\n");
    }
    
    return 0;
}*/