/*Dados três valores A, B e C, verificar se eles podem ser os comprimentos dos
lados de um triângulo, e se forem, verificar se compõem um triângulo eqüilátero,
isóscele ou escaleno.*/
/*#include <stdio.h>

int main() {
    int a, b, c;

    // Lê os valores do usuário
    printf("Digite os três lados do triângulo: ");
    scanf("%d %d %d", &a, &b, &c);

    // Verifica se os valores formam um triângulo
    if (a + b > c && a + c > b && b + c > a) {
        printf("Os valores formam um triângulo ");

        // Verifica se é equilátero, isósceles ou escaleno
        if (a == b && b == c) {
            printf("equilátero.\n");
        } else if (a == b || a == c || b == c) {
            printf("isósceles.\n");
        } else {
            printf("escaleno.\n");
        }
    } else {
        printf("Os valores não formam um triângulo.\n");
    }

    return 0;
}*/
