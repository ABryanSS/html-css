/*Faça um algoritmo que leia três notas de um aluno, calcule a média aritmética e
imprima uma mensagem dizendo a situação final do aluno, de acordo com os critérios
abaixo:
MÉDIA < 5 W RETIDO
MÉDIA >= 5 e MÉDIA < 7 W EXAME FINAL
MÉDIA >= 7 W APROVADO*/
/*#include <stdio.h>

int main() {
    float nota1, nota2, nota3, media;

    printf("Digite a primeira nota: ");
    scanf("%f", &nota1);

    printf("Digite a segunda nota: ");
    scanf("%f", &nota2);

    printf("Digite a terceira nota: ");
    scanf("%f", &nota3);

    media = (nota1 + nota2 + nota3) / 3;

    if (media < 5) {
        printf("Situacao: RETIDO\n");
    } else if (media < 7) {
        printf("Situacao: EXAME FINAL\n");
    } else {
        printf("Situacao: APROVADO\n");
    }

    return 0;
}*/