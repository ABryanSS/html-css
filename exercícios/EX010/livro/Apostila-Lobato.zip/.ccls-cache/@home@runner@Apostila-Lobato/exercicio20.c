/*Fazer um algoritmo para calcular a área de um triângulo retângulo.*/
/*#include <stdio.h>

int main() {
    float base, altura, area;

    // Lê a medida da base e da altura
    printf("Digite a medida da base: ");
    scanf("%f", &base);
    printf("Digite a medida da altura: ");
    scanf("%f", &altura);

    // Calcula a área
    area = (base * altura) / 2;

    // Imprime a área
    printf("A area do triangulo retangulo e: %.2f\n", area);

    return 0;
}*/