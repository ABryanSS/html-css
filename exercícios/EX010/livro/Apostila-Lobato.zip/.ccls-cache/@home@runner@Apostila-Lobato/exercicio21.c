/*Faça um algoritmo que leia o valor de uma mercadoria e o percentual de
desconto. O algoritmo deve exibir o novo valor da mercadoria com desconto.*/
/*#include <stdio.h>

int main() {
    float valor, percentualDesconto, valorComDesconto;

    // Lê o valor da mercadoria e o percentual de desconto
    printf("Digite o valor da mercadoria: ");
    scanf("%f", &valor);
    printf("Digite o percentual de desconto: ");
    scanf("%f", &percentualDesconto);

    // Calcula o novo valor com o desconto
    valorComDesconto = valor * (1 - percentualDesconto / 100);

    // Imprime o novo valor com o desconto
    printf("O novo valor da mercadoria com desconto e: R$ %.2f\n", valorComDesconto);

    return 0;
}*/