/*Fazer um algoritmo para transformar uma temperatura dada em graus Fahrenheit
em graus Celsius.
Fórmula: C = 5 / 9 * (F – 32)*/
/*#include <stdio.h>

int main() {
    float temperaturaF, temperaturaC;

    printf("Digite a temperatura em graus Fahrenheit: ");
    scanf("%f", &temperaturaF);

    // Conversão para Celsius
    temperaturaC = (temperaturaF - 32) * 5 / 9;

    printf("A temperatura em graus Celsius e: %.2f", temperaturaC);

    return 0;
}*/