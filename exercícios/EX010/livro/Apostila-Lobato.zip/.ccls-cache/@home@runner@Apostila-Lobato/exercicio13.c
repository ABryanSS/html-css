/*Faça um algoritmo que leia a distância percorrida e a velocidade média (Km/h) de
um veículo e calcule:
- O tempo aproximado (em horas) que o veículo gastou para realizar o trajeto;
- Considerando que o veículo faz 11 Km por litro, calcule o consumo de combustível.*/
/*#include <stdio.h>
int main(void){
float distancia, velomedia,thoras,consumo,trageto;
printf("Informe a distancia percorrida:\n");
 scanf("%f",&distancia);
printf("Informe a velocidade media:\n");
 scanf("%f",&velomedia);
  trageto = distancia / velomedia;
  printf("O tempo aproximado é:%.2f horas que o veiculo gastou para realizar o trajeto:\n", trageto);
  consumo = distancia / 11;
  printf("O consumo de combustivel é:%.2f litros.\n",consumo);
  return 0;
 }
*/