/*Faça um algoritmo que leia um número inteiro e imprima uma mensagem dizendo
se é par ou ímpar.*/
/*#include <stdio.h>

int main() {
    int num;
    
    printf("Digite um numero inteiro: ");
    scanf("%d", &num);
    
    if(num % 2 == 0) {
        printf("O numero digitado é par.\n");
    } else {
        printf("O numero digitado é impar.\n");
    }
    
    return 0;
}*/