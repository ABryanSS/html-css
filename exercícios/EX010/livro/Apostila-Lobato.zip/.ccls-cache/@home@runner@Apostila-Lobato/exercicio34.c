/*Fazer um algoritmo que leia dois valores A e B, representando os valores de uma
reta dada pela equação y = Ax + B, e determine três pontos quaisquer, representando
as coordenadas ( x , y ). Formato de saída:
Para x = w W P( x , y )*/
/*#include <stdio.h>

int main() {
    float a, b, x1, x2, x3, y1, y2, y3;

    // Lendo os valores de A e B
    printf("Digite o valor de A: ");
    scanf("%f", &a);
    printf("Digite o valor de B: ");
    scanf("%f", &b);

    // Lendo os valores de x
    printf("Digite o valor de x1: ");
    scanf("%f", &x1);
    printf("Digite o valor de x2: ");
    scanf("%f", &x2);
    printf("Digite o valor de x3: ");
    scanf("%f", &x3);

    // Calculando os valores de y
    y1 = a * x1 + b;
    y2 = a * x2 + b;
    y3 = a * x3 + b;

    // Imprimindo os pontos encontrados
    printf("Para x = %.2f, P(%.2f, %.2f)\n", x1, x1, y1);
    printf("Para x = %.2f, P(%.2f, %.2f)\n", x2, x2, y2);
    printf("Para x = %.2f, P(%.2f, %.2f)\n", x3, x3, y3);

    return 0;
}*/