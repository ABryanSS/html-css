/*18.Faça um algoritmo que leia os valores representando a quantidade de itens
solicitados em um restaurante e imprima o valor total a ser pago, considerando os
10% do garçom.
O valor da conta será calculado com base na tabela de preços mostrada abaixo:

TABELA DE PREÇOS:

Refeição .................. R$8,50 Prato Feito............... R$ 4,00
Refrigerante............. R$ 1,20 Cerveja .................... R$ 2,00
Tira-gosto ............... R$ 8,50 Água mineral ............ R$ 0,50*/
/*#include <stdio.h>

int main() {
    int qtdRefeicao, qtdPratoFeito, qtdRefrigerante, qtdCerveja, qtdTiraGosto, qtdAguaMineral;
    float totalRefeicao, totalPratoFeito, totalRefrigerante, totalCerveja, totalTiraGosto, totalAguaMineral;
    float subtotal, total, taxaGarcom;

    // Leitura das quantidades de cada item
    printf("Digite a quantidade de refeicoes: ");
    scanf("%d", &qtdRefeicao);

    printf("Digite a quantidade de pratos feitos: ");
    scanf("%d", &qtdPratoFeito);

    printf("Digite a quantidade de refrigerantes: ");
    scanf("%d", &qtdRefrigerante);

    printf("Digite a quantidade de cervejas: ");
    scanf("%d", &qtdCerveja);

    printf("Digite a quantidade de tira-gostos: ");
    scanf("%d", &qtdTiraGosto);

    printf("Digite a quantidade de aguas minerais: ");
    scanf("%d", &qtdAguaMineral);

    // Cálculo dos totais de cada item
    totalRefeicao = qtdRefeicao * 8.5;
    totalPratoFeito = qtdPratoFeito * 4.0;
    totalRefrigerante = qtdRefrigerante * 1.2;
    totalCerveja = qtdCerveja * 2.0;
    totalTiraGosto = qtdTiraGosto * 8.5;
    totalAguaMineral = qtdAguaMineral * 0.5;

    // Cálculo do subtotal
    subtotal = totalRefeicao + totalPratoFeito + totalRefrigerante + totalCerveja + totalTiraGosto + totalAguaMineral;

    // Cálculo da taxa do garçom
    taxaGarcom = subtotal * 0.1;

    // Cálculo do total a ser pago
    total = subtotal + taxaGarcom;

    // Impressão do valor total
    printf("Valor total a ser pago: R$%.2f (incluindo taxa de 10%% do garcom de R$%.2f)\n", total, taxaGarcom);

    return 0;
}*/