/*Fazer um algoritmo para inverter a ordem de determinado número de quatro
dígitos.*/
/*#include <stdio.h>
int main(void){
int numero, unidade, dezena, centena, milhar, numeroInvertido;
  printf("Informe um número de quatro digitos:\n");
    scanf("%d",&numero);
   // Separação dos dígitos
    unidade = numero % 10;
    numero = numero / 10;
    dezena = numero % 10;
    numero = numero / 10;
    centena = numero % 10;
    numero = numero / 10;
    milhar = numero % 10;
   // Inversão dos dígitos
    numeroInvertido = (unidade * 1000) + (dezena * 100) + (centena * 10) + milhar;
 printf("O numero invertido e: %d", numeroInvertido);
  return 0;
}*/