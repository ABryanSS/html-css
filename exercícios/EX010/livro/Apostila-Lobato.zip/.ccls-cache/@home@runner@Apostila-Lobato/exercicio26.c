/*Fazer um algoritmo que leia três valores inteiros, determine e imprima o menor
deles.*/
/*#include <stdio.h>

int main() {
    int a, b, c, menor;

    // Lê os três valores do usuário
    printf("Digite três valores inteiros: ");
    scanf("%d %d %d", &a, &b, &c);

    // Verifica qual é o menor valor
    if (a < b && a < c) {
        menor = a;
    } else if (b < c) {
        menor = b;
    } else {
        menor = c;
    }

    // Imprime o menor valor
    printf("O menor valor digitado foi %d\n", menor);

    return 0;
}*/