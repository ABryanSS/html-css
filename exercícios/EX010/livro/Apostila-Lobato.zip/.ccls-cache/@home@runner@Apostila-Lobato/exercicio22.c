/*Considerando duas variáveis inteiras quaisquer, após a entrada de dados, fazer a
troca do conteúdo de uma pelo conteúdo da outra.*/
/*#include <stdio.h>

int main() {
    int a, b, temp;

    // Lê os valores de a e b
    printf("Digite o valor de a: ");
    scanf("%d", &a);
    printf("Digite o valor de b: ");
    scanf("%d", &b);

    // Troca os valores de a e b usando uma variável auxiliar
    temp = a;
    a = b;
    b = temp;

    // Imprime os novos valores de a e b
    printf("Novo valor de a: %d\n", a);
    printf("Novo valor de b: %d\n", b);

    return 0;
}*/